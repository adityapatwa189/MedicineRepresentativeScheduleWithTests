using MedicineRepresentativeSchedule.Controllers;
using MedicineRepresentativeSchedule.Models;
using MedicineRepresentativeSchedule.Service;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Tests
{
    [TestFixture]
    public class UnitTest1
    {
        public Mock<IRepScheduleService> MockRepScheduleService;
        public IEnumerable<RepSchedule> _repSchedule;
        [SetUp]
        public void setup()
        {
            MockRepScheduleService = new Mock<IRepScheduleService>();
            _repSchedule = new List<RepSchedule>()
            {
            new RepSchedule{
                Name="Rep1",
                DocterName="Doc1",
                TreatmentAilment="general",
                Medicine="Gavisol",
                MettingSlot="1 pm to 2 pm",
                DateOfMetting=new DateTime(2022,2,4),
                DocterContactNumber="987654321"
                            }
            };
        }

        [TestCase("2022/11/12")]
        public void GetSchedule_ValidData_returnsOkObjectWithRepSchedule(DateTime ScheduleStartDate)
        {
            MockRepScheduleService.Setup(m => m.CreateRepSchedule(It.IsAny<DateTime>())).Returns(Task.FromResult(_repSchedule));
            RepScheduleController rep = new RepScheduleController(MockRepScheduleService.Object);
            var response =rep.GetSchedule(ScheduleStartDate).Result as ObjectResult;
            Assert.AreEqual(response.StatusCode, 200);
        }

        [TestCase("2022/11/12")]
        public void GetSchedule_NullData_returnsNotFound (DateTime ScheduleStartDate)
        {
            _repSchedule = null;
            MockRepScheduleService.Setup(m => m.CreateRepSchedule(It.IsAny<DateTime>())).Returns(Task.FromResult(_repSchedule));
            RepScheduleController rep = new RepScheduleController(MockRepScheduleService.Object);
            var response = rep.GetSchedule(ScheduleStartDate).Result as ObjectResult;
            Assert.AreEqual(response.StatusCode, 404);
        }
    }
}
